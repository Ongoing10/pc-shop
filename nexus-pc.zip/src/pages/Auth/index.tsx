import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams, Link } from 'react-router-dom';
import { Input, Button, Checkbox, message, Progress } from 'antd';
import { useTranslation } from 'react-i18next';
import {
  UserOutlined,
  LockOutlined,
  MailOutlined,
  PhoneOutlined,
  ThunderboltFilled,
  CheckCircleFilled,
} from '@ant-design/icons';
import { FiShield, FiCheck, FiX } from 'react-icons/fi';
import { Logo } from '../../components/common/Logo';
import { useAuth } from '../../context/AuthContext';
import { evaluatePasswordStrength, checkPasswordRequirements } from '../../services/api/authService';

export const AuthPage: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const { login, register, isAuthenticated } = useAuth();

  const initialMode = searchParams.get('tab') === 'register' ? 'register' : 'login';
  const [mode, setMode] = useState<'login' | 'register'>(initialMode);

  // Login form state
  const [loginIdentifier, setLoginIdentifier] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(true);

  // Register form state
  const [regFullName, setRegFullName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirmPassword, setRegConfirmPassword] = useState('');
  const [agreeTerms, setAgreeTerms] = useState(true);

  const [isLoading, setIsLoading] = useState(false);

  // Sync mode with query params
  useEffect(() => {
    const tabParam = searchParams.get('tab');
    if (tabParam === 'register' && mode !== 'register') {
      setMode('register');
    } else if (tabParam === 'login' && mode !== 'login') {
      setMode('login');
    }
  }, [searchParams]);

  const handleSwitchMode = (newMode: 'login' | 'register') => {
    setMode(newMode);
    setSearchParams(newMode === 'register' ? { tab: 'register' } : {});
  };

  const regStrength = evaluatePasswordStrength(regPassword);
  const regReqs = checkPasswordRequirements(regPassword);
  const regMatch = regPassword && regConfirmPassword && regPassword === regConfirmPassword;

  // Fill quick demo credentials
  const fillDemoAccount = () => {
    setLoginIdentifier('khachhang@novabuild.vn');
    setLoginPassword('123456');
    message.info('Đã điền tài khoản mẫu NovaBuild');
  };

  // Submit Login
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginIdentifier.trim() || !loginPassword.trim()) {
      message.warning('Vui lòng nhập đầy đủ tài khoản và mật khẩu.');
      return;
    }

    setIsLoading(true);
    try {
      await login({
        identifier: loginIdentifier.trim(),
        password: loginPassword,
        remember: rememberMe,
      });
      message.success('Đăng nhập thành công! Chào mừng bạn trở lại.');
      navigate('/account');
    } catch (err: any) {
      message.error(err?.message || 'Đăng nhập không thành công, vui lòng thử lại.');
    } finally {
      setIsLoading(false);
    }
  };

  // Submit Register
  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!regFullName.trim()) {
      message.warning('Vui lòng nhập họ và tên của bạn.');
      return;
    }
    if (!regEmail.trim()) {
      message.warning('Vui lòng nhập email.');
      return;
    }
    if (!regPhone.trim()) {
      message.warning('Vui lòng nhập số điện thoại.');
      return;
    }
    if (!regPassword || regPassword.length < 6) {
      message.warning('Mật khẩu phải có tối thiểu 6 ký tự.');
      return;
    }
    if (regPassword !== regConfirmPassword) {
      message.warning('Mật khẩu xác nhận không khớp.');
      return;
    }
    if (!agreeTerms) {
      message.warning('Vui lòng đồng ý với điều khoản dịch vụ.');
      return;
    }

    setIsLoading(true);
    try {
      await register({
        fullName: regFullName.trim(),
        email: regEmail.trim(),
        phone: regPhone.trim(),
        password: regPassword,
      });
      message.success('Đăng ký tài khoản thành công!');
      navigate('/account');
    } catch (err: any) {
      message.error(err?.message || 'Đăng ký không thành công.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <main className="auth">
      <section>
        <Logo />
        <div
          style={{
            display: 'flex',
            background: 'rgba(255,255,255,0.05)',
            padding: 3,
            borderRadius: 8,
            border: '1px solid rgba(255,255,255,0.1)',
            margin: '8px 0 16px',
          }}
        >
          <button
            type="button"
            onClick={() => handleSwitchMode('login')}
            style={{
              flex: 1,
              padding: '8px 12px',
              border: 0,
              borderRadius: 6,
              background: mode === 'login' ? '#67e8f9' : 'transparent',
              color: mode === 'login' ? '#0a0d1a' : '#888',
              fontWeight: 700,
              fontSize: 12,
              cursor: 'pointer',
              transition: 'all 0.2s',
            }}
          >
            {t('nav.login', 'ĐĂNG NHẬP')}
          </button>
          <button
            type="button"
            onClick={() => handleSwitchMode('register')}
            style={{
              flex: 1,
              padding: '8px 12px',
              border: 0,
              borderRadius: 6,
              background: mode === 'register' ? '#67e8f9' : 'transparent',
              color: mode === 'register' ? '#0a0d1a' : '#888',
              fontWeight: 700,
              fontSize: 12,
              cursor: 'pointer',
              transition: 'all 0.2s',
            }}
          >
            {t('auth.btnRegister', 'ĐĂNG KÝ')}
          </button>
        </div>

        <h1>
          {mode === 'login'
            ? t('auth.loginTitle', 'Chào mừng trở lại.')
            : t('auth.registerTitle', 'Tạo tài khoản mới.')}
        </h1>

        <p style={{ color: '#9ba1b0', fontSize: 12, margin: '4px 0 16px', lineHeight: 1.6 }}>
          {mode === 'login'
            ? t(
                'auth.loginSubtitle',
                'Đăng nhập để theo dõi đơn hàng, lưu cấu hình PC và nhận khuyến mãi.'
              )
            : t(
                'auth.registerSubtitle',
                'Tham gia cộng đồng NovaBuild để nhận ưu đãi phần cứng độc quyền.'
              )}
        </p>

        {/* LOGIN FORM */}
        {mode === 'login' && (
          <form onSubmit={handleLoginSubmit} style={{ display: 'grid', gap: 14 }}>
            <label style={{ display: 'grid', gap: 6, fontSize: 12, color: '#ccc' }}>
              <span>{t('auth.emailPhonePlaceholder', 'Email hoặc số điện thoại')}</span>
              <Input
                prefix={<UserOutlined style={{ color: '#888' }} />}
                placeholder="Ví dụ: khachhang@novabuild.vn hoặc 0988888888"
                value={loginIdentifier}
                onChange={(e) => setLoginIdentifier(e.target.value)}
                size="large"
                autoFocus
              />
            </label>

            <label style={{ display: 'grid', gap: 6, fontSize: 12, color: '#ccc' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span>{t('auth.passwordPlaceholder', 'Mật khẩu')}</span>
                <Link
                  to="/forgot-password"
                  style={{ color: '#67e8f9', fontSize: 11, fontWeight: 500 }}
                >
                  {t('auth.forgotPasswordLink', 'Quên mật khẩu?')}
                </Link>
              </div>
              <Input.Password
                prefix={<LockOutlined style={{ color: '#888' }} />}
                placeholder="Nhập mật khẩu của bạn"
                value={loginPassword}
                onChange={(e) => setLoginPassword(e.target.value)}
                size="large"
              />
            </label>

            {/* Quick Demo Autofill Pill */}
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                padding: '8px 12px',
                background: '#121629',
                border: '1px dashed rgba(255,255,255,0.15)',
                borderRadius: 6,
                fontSize: 11,
                color: '#8f95a5',
              }}
            >
              <span>Demo: <b>khachhang@novabuild.vn</b> / <b>123456</b></span>
              <button
                type="button"
                onClick={fillDemoAccount}
                style={{
                  background: 'none',
                  border: 'none',
                  color: '#67e8f9',
                  fontWeight: 600,
                  cursor: 'pointer',
                  padding: 0,
                }}
              >
                Điền mẫu
              </button>
            </div>

            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <Checkbox
                checked={rememberMe}
                onChange={(e) => setRememberMe(e.target.checked)}
                style={{ color: '#aaa', fontSize: 12 }}
              >
                {t('auth.rememberMe', 'Ghi nhớ đăng nhập')}
              </Checkbox>
            </div>

            <Button
              type="primary"
              block
              size="large"
              htmlType="submit"
              loading={isLoading}
              style={{ height: 42, fontSize: 13, fontWeight: 700 }}
            >
              {t('auth.btnLogin', 'Đăng nhập ngay')}
            </Button>
          </form>
        )}

        {/* REGISTER FORM */}
        {mode === 'register' && (
          <form onSubmit={handleRegisterSubmit} style={{ display: 'grid', gap: 12 }}>
            <label style={{ display: 'grid', gap: 5, fontSize: 12, color: '#ccc' }}>
              <span>{t('auth.namePlaceholder', 'Họ và tên của bạn')} *</span>
              <Input
                prefix={<UserOutlined style={{ color: '#888' }} />}
                placeholder="Ví dụ: Nguyễn Văn Hưng"
                value={regFullName}
                onChange={(e) => setRegFullName(e.target.value)}
                size="large"
                autoFocus
              />
            </label>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
              <label style={{ display: 'grid', gap: 5, fontSize: 12, color: '#ccc' }}>
                <span>Email *</span>
                <Input
                  prefix={<MailOutlined style={{ color: '#888' }} />}
                  placeholder="name@email.com"
                  value={regEmail}
                  onChange={(e) => setRegEmail(e.target.value)}
                  size="large"
                />
              </label>

              <label style={{ display: 'grid', gap: 5, fontSize: 12, color: '#ccc' }}>
                <span>Số điện thoại *</span>
                <Input
                  prefix={<PhoneOutlined style={{ color: '#888' }} />}
                  placeholder="09xx xxx xxx"
                  value={regPhone}
                  onChange={(e) => setRegPhone(e.target.value)}
                  size="large"
                />
              </label>
            </div>

            <label style={{ display: 'grid', gap: 5, fontSize: 12, color: '#ccc' }}>
              <span>{t('auth.passwordPlaceholder', 'Mật khẩu')} *</span>
              <Input.Password
                prefix={<LockOutlined style={{ color: '#888' }} />}
                placeholder="Tối thiểu 6 ký tự"
                value={regPassword}
                onChange={(e) => setRegPassword(e.target.value)}
                size="large"
              />
            </label>

            {/* Live Password Strength Meter */}
            {regPassword && (
              <div
                style={{
                  background: '#0d1224',
                  border: '1px solid rgba(255,255,255,0.1)',
                  borderRadius: 6,
                  padding: '8px 10px',
                }}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, marginBottom: 4 }}>
                  <span style={{ color: '#888' }}>{t('auth.passwordStrength', 'Độ mạnh')}:</span>
                  <span style={{ color: regStrength.color, fontWeight: 700 }}>{regStrength.label}</span>
                </div>
                <Progress percent={regStrength.score} showInfo={false} strokeColor={regStrength.color} size="small" />
                <div style={{ display: 'flex', gap: 10, marginTop: 4, fontSize: 10 }}>
                  <span style={{ color: regReqs.minLength ? '#34d399' : '#888' }}>
                    {regReqs.minLength ? '✓' : '○'} ≥ 6 ký tự
                  </span>
                  <span style={{ color: regReqs.hasNumber ? '#34d399' : '#888' }}>
                    {regReqs.hasNumber ? '✓' : '○'} Có số
                  </span>
                </div>
              </div>
            )}

            <label style={{ display: 'grid', gap: 5, fontSize: 12, color: '#ccc' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span>{t('auth.confirmPasswordPlaceholder', 'Xác nhận mật khẩu')} *</span>
                {regConfirmPassword && (
                  <span style={{ fontSize: 11, color: regMatch ? '#34d399' : '#f43f5e' }}>
                    {regMatch ? '✓ Khớp' : '✗ Chưa khớp'}
                  </span>
                )}
              </div>
              <Input.Password
                prefix={<LockOutlined style={{ color: '#888' }} />}
                placeholder="Nhập lại mật khẩu vừa tạo"
                value={regConfirmPassword}
                onChange={(e) => setRegConfirmPassword(e.target.value)}
                size="large"
              />
            </label>

            <Checkbox
              checked={agreeTerms}
              onChange={(e) => setAgreeTerms(e.target.checked)}
              style={{ color: '#9ba1b0', fontSize: 11, marginTop: 4 }}
            >
              Tôi đồng ý với Điều khoản dịch vụ và Chính sách của NovaBuild.
            </Checkbox>

            <Button
              type="primary"
              block
              size="large"
              htmlType="submit"
              loading={isLoading}
              style={{ height: 42, fontSize: 13, fontWeight: 700, marginTop: 4 }}
            >
              {t('auth.btnRegister', 'Đăng ký tài khoản mới')}
            </Button>
          </form>
        )}

        <p style={{ marginTop: 14 }}>
          {mode === 'login'
            ? t('auth.noAccount', 'Chưa có tài khoản?')
            : t('auth.hasAccount', 'Đã có tài khoản?')}{' '}
          <button
            onClick={() => handleSwitchMode(mode === 'login' ? 'register' : 'login')}
            type="button"
            style={{ fontWeight: 700, color: '#67e8f9', cursor: 'pointer' }}
          >
            {mode === 'login'
              ? t('auth.btnRegister', 'Đăng ký ngay')
              : t('auth.btnLogin', 'Đăng nhập ngay')}
          </button>
        </p>
      </section>

      <aside>
        <small style={{ color: '#67e8f9', letterSpacing: '0.1em', fontWeight: 600 }}>
          <ThunderboltFilled style={{ marginRight: 6 }} />
          PERFORMANCE STARTS HERE
        </small>
        <h2>
          Build your
          <br />
          <em>next level.</em>
        </h2>
        <div style={{ marginTop: 24, display: 'flex', gap: 16, fontSize: 11, color: '#a0a5b5' }}>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
            <CheckCircleFilled style={{ color: '#34d399' }} /> 100% Chính hãng
          </span>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
            <CheckCircleFilled style={{ color: '#34d399' }} /> Bảo hành 36 tháng
          </span>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
            <CheckCircleFilled style={{ color: '#34d399' }} /> Hỗ trợ 24/7
          </span>
        </div>
      </aside>
    </main>
  );
};
