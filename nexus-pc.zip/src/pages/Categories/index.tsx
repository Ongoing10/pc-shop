import React from 'react';
import { Link } from 'react-router-dom';
import { Spin } from 'antd';
import { useTranslation } from 'react-i18next';
import { ArrowRightOutlined, ThunderboltOutlined } from '@ant-design/icons';
import { Breadcrumb } from '../../components/common/Breadcrumb';
import { Reveal } from '../../components/common/Reveal';
import { useCategories } from '../../hooks/useCategories';

export const CategoriesPage: React.FC = () => {
  const { t } = useTranslation();
  const { data: categories = [], isLoading } = useCategories();

  return (
    <main className="container page">
      <Breadcrumb items={[t('nav.components', 'Linh kiện')]} />

      <div className="pagehead">
        <div>
          <small className="kicker" style={{ display: 'block', marginBottom: 4 }}>NOVABUILD HARDWARE HUB</small>
          <h1>{t('nav.components', 'Danh mục linh kiện PC')}</h1>
          <p>{t('categories.subtitle', 'Khám phá hệ sinh thái linh kiện chính hãng kiểm định nghiêm ngặt cho mọi phân khúc.')}</p>
        </div>
        <Link to="/builder">
          <button className="px-6 py-3 bg-gradient-to-r from-cyan-400 to-blue-500 text-slate-950 font-bold rounded-xl shadow-lg shadow-cyan-500/20 hover:scale-[1.03] transition-all flex items-center gap-2">
            <ThunderboltOutlined />
            <span>{t('nav.builder', 'Tự Build PC ngay')}</span>
          </button>
        </Link>
      </div>

      {isLoading ? (
        <div className="text-center py-24"><Spin size="large" /></div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 my-8">
          {categories.map((c, i) => (
            <Reveal key={c.id} delay={i * 40}>
              <Link
                to={`/products?category=${c.id}`}
                className="group p-6 rounded-2xl bg-slate-900/80 backdrop-blur-xl border border-white/10 hover:border-cyan-500/60 transition-all duration-300 flex flex-col justify-between shadow-xl hover:shadow-cyan-500/10 min-h-[200px]"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-14 h-14 rounded-xl bg-cyan-950/60 border border-cyan-500/30 text-cyan-400 flex items-center justify-center text-2xl font-mono">
                      {c.icon}
                    </div>
                    <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-slate-800 text-cyan-400 border border-white/5">
                      {c.count} sản phẩm
                    </span>
                  </div>

                  <h3 className="text-lg font-bold text-white group-hover:text-cyan-400 transition-colors mb-2">
                    {c.name}
                  </h3>
                  <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
                    {c.description || 'Linh kiện chính hãng hiệu năng cao, bảo hành 36 tháng.'}
                  </p>
                </div>

                <div className="pt-4 mt-4 border-t border-white/10 flex items-center justify-between text-xs font-semibold text-cyan-400 group-hover:translate-x-1 transition-transform">
                  <span>Khám phá danh mục</span>
                  <ArrowRightOutlined />
                </div>
              </Link>
            </Reveal>
          ))}
        </div>
      )}
    </main>
  );
};
