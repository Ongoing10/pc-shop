import React from 'react';
import { Link } from 'react-router-dom';
import { Spin } from 'antd';
import { useTranslation } from 'react-i18next';
import {
  ArrowRightOutlined,
  CheckCircleOutlined,
  RightOutlined,
} from '@ant-design/icons';
import {
  FiTruck,
  FiShield,
  FiHeadphones,
  FiCreditCard,
} from 'react-icons/fi';
import { Reveal } from '../../components/common/Reveal';
import { ProductCard } from '../../components/common/ProductCard';
import { ProductGridSkeleton } from '../../components/common/CustomSkeleton';
import { useCategories } from '../../hooks/useCategories';
import { useFeaturedProducts, useDealProducts } from '../../hooks/useProducts';
import Hero from '../../components/Hero/Hero';

export const HomePage: React.FC = () => {
  const { t } = useTranslation();
  const { data: categories = [], isLoading: loadingCats } = useCategories();
  const { data: featuredProducts = [], isLoading: loadingFeatured } = useFeaturedProducts(4);
  const { data: dealProducts = [], isLoading: loadingDeals } = useDealProducts(4);

  return (
    <main className="pb-24 overflow-hidden bg-[#0a0d1a] text-slate-100">
      <Hero />

      {/* Benefits Bar */}
      <div className="container mx-auto px-4 md:px-6 py-12">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 p-6 rounded-2xl bg-slate-900/80 backdrop-blur-xl border border-white/10 shadow-xl">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-cyan-950/60 border border-cyan-500/30 text-cyan-400 flex items-center justify-center shrink-0">
              <FiTruck className="text-xl" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">{t('benefits.nationwideDelivery', 'Giao hàng toàn quốc')}</h4>
              <p className="text-xs text-slate-400 mt-0.5">{t('benefits.safePackaging', 'Đóng gói chống sốc 3 lớp')}</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-cyan-950/60 border border-cyan-500/30 text-cyan-400 flex items-center justify-center shrink-0">
              <FiShield className="text-xl" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">{t('benefits.genuine100', 'Chính hãng 100%')}</h4>
              <p className="text-xs text-slate-400 mt-0.5">{t('benefits.transparentWarranty', 'Bảo hành hãng minh bạch')}</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-cyan-950/60 border border-cyan-500/30 text-cyan-400 flex items-center justify-center shrink-0">
              <FiHeadphones className="text-xl" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">{t('benefits.expertConsultation', 'Tư vấn chuyên sâu')}</h4>
              <p className="text-xs text-slate-400 mt-0.5">{t('benefits.rightBuild', 'Đội ngũ kỹ thuật trưởng')}</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-cyan-950/60 border border-cyan-500/30 text-cyan-400 flex items-center justify-center shrink-0">
              <FiCreditCard className="text-xl" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">{t('benefits.flexiblePayment', 'Thanh toán linh hoạt')}</h4>
              <p className="text-xs text-slate-400 mt-0.5">{t('benefits.multiMethods', 'COD, chuyển khoản, trả góp')}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Categories Grid */}
      <section className="container mx-auto px-4 md:px-6 py-8">
        <Reveal>
          <div className="flex items-end justify-between mb-8">
            <div>
              <span className="text-xs font-semibold tracking-wider text-cyan-400 uppercase">EXPLORE COMPONENTS</span>
              <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-white mt-1">
                {t('sections.exploreComponents', 'Danh mục linh kiện')}
              </h2>
            </div>
            <Link to="/products" className="text-sm font-semibold text-cyan-400 hover:text-cyan-300 flex items-center gap-1.5 transition-colors">
              {t('common.viewAll', 'Xem tất cả')} <ArrowRightOutlined />
            </Link>
          </div>
        </Reveal>

        {loadingCats ? (
          <div className="text-center py-16"><Spin size="large" /></div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {categories.map((c, i) => (
              <Reveal key={c.id} delay={i * 35}>
                <Link
                  to={`/products?category=${c.id}`}
                  className="group p-6 rounded-2xl bg-slate-900/80 backdrop-blur-xl border border-white/10 hover:border-cyan-500/60 transition-all duration-300 flex items-center justify-between shadow-xl hover:shadow-cyan-500/10"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-xl bg-slate-800 text-slate-300 group-hover:bg-cyan-950/60 group-hover:text-cyan-400 transition-colors flex items-center justify-center text-xl border border-white/5">
                      {c.icon}
                    </div>
                    <div>
                      <h3 className="text-base font-bold text-white group-hover:text-cyan-400 transition-colors">
                        {c.name}
                      </h3>
                      <p className="text-xs text-slate-400 mt-0.5">{c.count} sản phẩm</p>
                    </div>
                  </div>
                  <div className="w-8 h-8 rounded-full bg-slate-800 group-hover:bg-cyan-500 group-hover:text-slate-950 text-slate-400 transition-all flex items-center justify-center">
                    <RightOutlined className="text-xs" />
                  </div>
                </Link>
              </Reveal>
            ))}
          </div>
        )}
      </section>

      {/* Featured Products */}
      <section className="container mx-auto px-4 md:px-6 py-12">
        <Reveal>
          <div className="flex items-end justify-between mb-8">
            <div>
              <span className="text-xs font-semibold tracking-wider text-cyan-400 uppercase">STAFF PICKS</span>
              <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-white mt-1">
                {t('sections.staffPicks', 'Sản phẩm nổi bật')}
              </h2>
            </div>
            <Link to="/products" className="text-sm font-semibold text-cyan-400 hover:text-cyan-300 flex items-center gap-1.5 transition-colors">
              {t('common.viewAll', 'Xem tất cả')} <ArrowRightOutlined />
            </Link>
          </div>
        </Reveal>

        {loadingFeatured ? (
          <ProductGridSkeleton count={4} columns={4} />
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredProducts.map((product, i) => (
              <Reveal key={product.id} delay={i * 50}>
                <ProductCard product={product} />
              </Reveal>
            ))}
          </div>
        )}
      </section>

      {/* PC Builder Promo Banner */}
      <section className="container mx-auto px-4 md:px-6 py-8">
        <div className="relative rounded-3xl overflow-hidden bg-slate-950 text-white border border-white/15 shadow-2xl">
          <div className="absolute inset-0 opacity-30 mix-blend-overlay">
            <img
              src="/src/assets/images/builder_showcase_1793798677194.jpg"
              alt="Builder showcase"
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-950/90 to-transparent" />
          
          <div className="relative z-10 p-8 sm:p-12 lg:p-16 max-w-2xl space-y-6">
            <div className="inline-flex items-center gap-2 text-xs font-semibold tracking-wider text-cyan-400 uppercase">
              <span>NEXUS BUILDER STUDIO</span>
              <span aria-hidden="true">·</span>
              <span>100% TƯƠNG THÍCH</span>
            </div>
            
            <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight">
              {t('sections.promoBuilderTitle', 'Build it your way.')}
            </h2>
            
            <p className="text-slate-300 text-base leading-relaxed">
              {t(
                'sections.promoBuilderDesc',
                'Hệ thống tự build thông minh tự động kiểm tra điện áp, kích thước tản nhiệt và khe cắm mainboard. Không lo lệch chuẩn.'
              )}
            </p>

            <div className="pt-2">
              <Link to="/builder">
                <button className="px-8 py-4 bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-slate-950 font-bold rounded-xl shadow-lg shadow-cyan-500/20 transition-all duration-200 hover:scale-[1.03] active:scale-[0.98] flex items-center gap-2.5 cursor-pointer">
                  <span>{t('sections.promoBuilderCta', 'Bắt đầu build PC ngay')}</span>
                  <ArrowRightOutlined />
                </button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Deals / Flash Sale Section */}
      <section className="container mx-auto px-4 md:px-6 py-12">
        <Reveal>
          <div className="flex items-end justify-between mb-8">
            <div>
              <span className="text-xs font-semibold tracking-wider text-cyan-400 uppercase">DEALS YOU SHOULD NOT MISS</span>
              <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-white mt-1">
                {t('sections.dealsTitle', 'Ưu đãi nổi bật')}
              </h2>
            </div>
            <Link to="/products?sort=discount" className="text-sm font-semibold text-cyan-400 hover:text-cyan-300 flex items-center gap-1.5 transition-colors">
              {t('common.viewAll', 'Khám phá ưu đãi')} <ArrowRightOutlined />
            </Link>
          </div>
        </Reveal>

        {loadingDeals ? (
          <ProductGridSkeleton count={4} columns={4} />
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {dealProducts.map((product, i) => (
              <Reveal key={product.id} delay={i * 50}>
                <ProductCard product={product} />
              </Reveal>
            ))}
          </div>
        )}
      </section>

      {/* Trust & Guarantee */}
      <section className="container mx-auto px-4 md:px-6 py-12">
        <div className="p-8 sm:p-12 rounded-3xl bg-slate-900/80 backdrop-blur-xl border border-white/10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center shadow-xl">
          <div className="lg:col-span-6 space-y-3">
            <span className="text-xs font-semibold tracking-wider text-cyan-400 uppercase">THE NEXUS STANDARD</span>
            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
              {t('sections.trustTitle', 'Không chỉ bán linh kiện.')}
              <span className="block text-cyan-400">{t('sections.trustTitleEm', 'Chúng tôi build trải nghiệm.')}</span>
            </h2>
          </div>
          <div className="lg:col-span-6 space-y-4">
            <div className="flex items-start gap-3">
              <div className="w-6 h-6 rounded-full bg-cyan-950/60 border border-cyan-500/30 text-cyan-400 flex items-center justify-center shrink-0 mt-0.5">
                <CheckCircleOutlined className="text-xs" />
              </div>
              <p className="text-sm font-medium text-slate-300">
                {t('sections.trustItem1', 'Tư vấn theo đúng nhu cầu thực tế và ngân sách của khách hàng.')}
              </p>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-6 h-6 rounded-full bg-cyan-950/60 border border-cyan-500/30 text-cyan-400 flex items-center justify-center shrink-0 mt-0.5">
                <CheckCircleOutlined className="text-xs" />
              </div>
              <p className="text-sm font-medium text-slate-300">
                {t('sections.trustItem2', 'Kiểm tra kỹ thuật nghiêm ngặt từng linh kiện trước khi giao hàng.')}
              </p>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-6 h-6 rounded-full bg-cyan-950/60 border border-cyan-500/30 text-cyan-400 flex items-center justify-center shrink-0 mt-0.5">
                <CheckCircleOutlined className="text-xs" />
              </div>
              <p className="text-sm font-medium text-slate-300">
                {t('sections.trustItem3', 'Hỗ trợ kỹ thuật, vệ sinh định kỳ và bảo hành siêu tốc sau mua hàng.')}
              </p>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
};
