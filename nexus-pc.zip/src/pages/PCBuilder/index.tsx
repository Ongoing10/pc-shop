import React, { useState } from 'react';
import { Button, Drawer, Divider, Tag, message } from 'antd';
import { useTranslation } from 'react-i18next';
import { DeleteOutlined } from '@ant-design/icons';
import { FiCpu, FiCheckCircle } from 'react-icons/fi';
import { Breadcrumb } from '../../components/common/Breadcrumb';
import { useProducts } from '../../hooks/useProducts';
import { useCart } from '../../context/CartContext';
import { BuilderSlotId, Product, RigBuild } from '../../types/product';
import { formatCurrency, calculateRigTotal } from '../../utils/format';
import { BuilderSkeleton, PicklistSkeleton } from '../../components/common/CustomSkeleton';

interface SlotConfig {
  id: BuilderSlotId;
  labelKey: string;
  defaultLabel: string;
}

const BUILDER_SLOTS: SlotConfig[] = [
  { id: 'cpu', labelKey: 'cpu', defaultLabel: 'Bộ vi xử lý (CPU)' },
  { id: 'mainboard', labelKey: 'mainboard', defaultLabel: 'Bo mạch chủ (Mainboard)' },
  { id: 'ram', labelKey: 'ram', defaultLabel: 'Bộ nhớ RAM' },
  { id: 'gpu', labelKey: 'gpu', defaultLabel: 'Card đồ họa (VGA)' },
  { id: 'ssd', labelKey: 'ssd', defaultLabel: 'Ổ cứng SSD' },
  { id: 'psu', labelKey: 'psu', defaultLabel: 'Nguồn máy tính (PSU)' },
  { id: 'case', labelKey: 'case', defaultLabel: 'Vỏ case máy tính' },
  { id: 'cooler', labelKey: 'cooler', defaultLabel: 'Tản nhiệt CPU' },
];

export const PCBuilderPage: React.FC = () => {
  const { t } = useTranslation();
  const { addToCart } = useCart();
  const [rig, setRig] = useState<RigBuild>({});
  const [activeSlot, setActiveSlot] = useState<BuilderSlotId | null>(null);

  const { data: allProducts = [], isLoading } = useProducts();

  const total = calculateRigTotal(rig);
  const selectedCount = Object.keys(rig).length;
  const progressPercent = (selectedCount / BUILDER_SLOTS.length) * 100;

  const currentSlotConfig = BUILDER_SLOTS.find((s) => s.id === activeSlot);
  const availablePartsForSlot = activeSlot
    ? allProducts.filter((p) => p.category === activeSlot)
    : [];

  const handleSelectProduct = (product: Product) => {
    if (activeSlot) {
      setRig((prev) => ({ ...prev, [activeSlot]: product }));
      setActiveSlot(null);
      message.success(`Đã thêm ${product.name} vào cấu hình`);
    }
  };

  const handleRemoveSlot = (slotId: BuilderSlotId) => {
    setRig((prev) => {
      const next = { ...prev };
      delete next[slotId];
      return next;
    });
  };

  const handleAddAllToCart = () => {
    const productsToAdd = Object.values(rig).filter((p): p is Product => Boolean(p));
    if (productsToAdd.length === 0) return;

    productsToAdd.forEach((p) => {
      addToCart(p, 1);
    });
    message.success(`Đã thêm ${productsToAdd.length} linh kiện vào giỏ hàng`);
  };

  return (
    <main className="container page">
      <Breadcrumb items={[t('nav.builder', 'PC Builder')]} />

      <div className="pagehead">
        <div>
          <h1>{t('builder.title', 'PC Builder')}</h1>
          <p>{t('builder.subtitle', 'Tự tay lựa chọn linh kiện và xây dựng cấu hình theo ngân sách.')}</p>
        </div>
        <Tag color="processing" style={{ padding: '6px 12px', fontSize: 12 }}>
          {t('builder.yourBuild', 'Bản dựng của bạn')}
        </Tag>
      </div>

      {isLoading ? (
        <BuilderSkeleton />
      ) : (
        <div className="builder">
          {/* Slot List */}
          <div className="slotlist">
            {BUILDER_SLOTS.map((slot, index) => {
              const product = rig[slot.id];
              return (
                <div className="slot" key={slot.id}>
                  <b>{String(index + 1).padStart(2, '0')}</b>
                  <span>
                    <strong>{slot.defaultLabel}</strong>
                    <small style={{ color: product ? '#f4f4f5' : '#888c96' }}>
                      {product ? product.name : t('builder.notSelected', 'Chưa chọn linh kiện')}
                    </small>
                  </span>
                  {product && <em>{formatCurrency(product.price)}</em>}
                  <Button
                    onClick={() => setActiveSlot(slot.id)}
                    type={product ? 'default' : 'primary'}
                  >
                    {product ? t('builder.changeComponent', 'Thay đổi') : t('builder.selectComponent', 'Chọn linh kiện')}
                  </Button>
                  {product && (
                    <button
                      onClick={() => handleRemoveSlot(slot.id)}
                      aria-label={`Remove ${slot.id}`}
                      type="button"
                    >
                      <DeleteOutlined />
                    </button>
                  )}
                </div>
              );
            })}
          </div>

          {/* Rig Summary Sidebar */}
          <aside className="summary">
            <small>{t('builder.eyebrow', 'BUILD SUMMARY')}</small>
            <h3>{t('builder.summaryTitle', 'Cấu hình của bạn')}</h3>
            <h2>
              {selectedCount}
              <small> / {BUILDER_SLOTS.length} linh kiện</small>
            </h2>

            <div className="progress" role="progressbar" aria-valuenow={progressPercent} aria-valuemin={0} aria-valuemax={100}>
              <i style={{ width: `${progressPercent}%` }} />
            </div>

            <div style={{ maxHeight: 240, overflowY: 'auto', marginBottom: 12 }}>
              {Object.entries(rig).map(([slotKey, p]) => {
                if (!p) return null;
                const slotCfg = BUILDER_SLOTS.find((s) => s.id === slotKey);
                return (
                  <p key={slotKey} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, margin: '6px 0' }}>
                    <span>{slotCfg?.defaultLabel.split(' ')[0]}</span>
                    <b>{formatCurrency(p.price)}</b>
                  </p>
                );
              })}
            </div>

            <Divider />

            <div style={{ marginBottom: 12 }}>
              <span style={{ fontSize: 12, color: '#aaa' }}>{t('builder.estimatedTotal', 'Tổng tạm tính')}:</span>
              <h3 className="orange" style={{ margin: '4px 0 0' }}>{formatCurrency(total)}</h3>
            </div>

            <Button
              type="primary"
              block
              size="large"
              disabled={selectedCount === 0}
              onClick={handleAddAllToCart}
            >
              {t('builder.addRigToCart', 'Thêm cấu hình vào giỏ')}
            </Button>

            <small className="muted" style={{ display: 'flex', gap: 6, alignItems: 'flex-start', marginTop: 14 }}>
              <FiCheckCircle style={{ color: '#45bf8c', flexShrink: 0, marginTop: 2 }} />
              <span>{t('builder.compatibilityNote', 'Kiểm tra tương thích chuyên sâu chuẩn ATX 3.0, Socket AM5/LGA1700 và kích thước Card đồ họa.')}</span>
            </small>
          </aside>
        </div>
      )}

      {/* Drawer to Pick Part for Slot */}
      <Drawer
        title={
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <FiCpu style={{ color: '#67e8f9' }} />
            <span>{currentSlotConfig ? `Chọn ${currentSlotConfig.defaultLabel}` : 'Chọn linh kiện'}</span>
          </div>
        }
        open={Boolean(activeSlot)}
        onClose={() => setActiveSlot(null)}
        styles={{ wrapper: { width: 480, maxWidth: '100vw' } }}
      >
        <div className="picklist">
          {isLoading ? (
            <PicklistSkeleton count={4} />
          ) : (
            availablePartsForSlot.map((p) => (
              <div key={p.id}>
                <img src={p.image} alt={p.name} />
                <span>
                  <b>{p.name}</b>
                  <div style={{ fontSize: 10, color: '#888', marginTop: 2 }}>{p.specs.slice(0, 2).join(' · ')}</div>
                  <strong>{formatCurrency(p.price)}</strong>
                </span>
                <Button type="primary" size="small" onClick={() => handleSelectProduct(p)}>
                  {t('common.buyNow', 'Chọn')}
                </Button>
              </div>
            ))
          )}
          {!isLoading && availablePartsForSlot.length === 0 && (
            <div style={{ textAlign: 'center', padding: 30, color: '#888' }}>
              Không có sản phẩm nào cho danh mục này.
            </div>
          )}
        </div>
      </Drawer>
    </main>
  );
};
