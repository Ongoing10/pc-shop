import React from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { FiHeadphones, FiMail, FiMapPin, FiShield } from 'react-icons/fi';
import { Logo } from '../common/Logo';

export const Footer: React.FC = () => {
  const { t } = useTranslation();

  return (
    <footer className="footer">
      <div className="container footgrid">
        <div>
          <Logo />
          <p>
            {t(
              'footer.aboutText',
              'Nơi bắt đầu cho bộ PC tiếp theo của bạn. Linh kiện chính hãng 100%, tư vấn đúng nhu cầu, đồng hành trong từng trải nghiệm.'
            )}
          </p>
        </div>
        <div>
          <b>{t('footer.aboutTitle', 'Về NovaBuild')}</b>
          <Link to="/products">{t('footer.aboutLink1', 'Giới thiệu thương hiệu')}</Link>
          <a href="#contact">{t('footer.aboutLink2', 'Liên hệ hợp tác')}</a>
          <a href="#news">{t('footer.aboutLink3', 'Tin tức công nghệ')}</a>
        </div>
        <div>
          <b>{t('footer.supportTitle', 'Hỗ trợ khách hàng')}</b>
          <Link to="/track-order">{t('footer.supportLink1', 'Tra cứu đơn hàng')}</Link>
          <a href="#shipping">{t('footer.supportLink2', 'Chính sách vận chuyển')}</a>
          <a href="#warranty">{t('footer.supportLink3', 'Chính sách bảo hành')}</a>
          <a href="#refund">{t('footer.supportLink4', 'Đổi trả & hoàn tiền')}</a>
        </div>
        <div>
          <b>{t('footer.contactTitle', 'Liên hệ')}</b>
          <p>
            <FiHeadphones style={{ verticalAlign: 'middle', marginRight: 8, color: '#67e8f9' }} />
            {t('footer.phone', '1900 6868')}
          </p>
          <p>
            <FiMail style={{ verticalAlign: 'middle', marginRight: 8, color: '#67e8f9' }} />
            {t('footer.email', 'support@novabuild.vn')}
          </p>
          <p>
            <FiMapPin style={{ verticalAlign: 'middle', marginRight: 8, color: '#67e8f9' }} />
            {t('footer.address', 'Hà Nội, Việt Nam')}
          </p>
        </div>
      </div>
      <div className="container footbottom">
        <span>{t('footer.copyright', '© 2026 NovaBuild. All rights reserved.')}</span>
        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
          <FiShield style={{ color: '#34d399' }} />
          {t('footer.securityBadge', 'Thanh toán an toàn · Bảo hành chính hãng')}
        </span>
      </div>
    </footer>
  );
};
