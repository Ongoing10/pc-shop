import React, { useState } from 'react';
import { NavLink, Link, useNavigate } from 'react-router-dom';
import { Badge, Drawer, Dropdown, MenuProps, Tooltip } from 'antd';
import { useTranslation } from 'react-i18next';
import {
  MenuOutlined,
  SearchOutlined,
  AppstoreOutlined,
  FireFilled,
  DownOutlined,
  LogoutOutlined,
  KeyOutlined,
} from '@ant-design/icons';
import {
  FiShoppingCart,
  FiUser,
  FiTruck,
  FiHeadphones,
  FiCpu,
  FiLock,
  FiPackage,
} from 'react-icons/fi';
import { TbArrowsDiff } from 'react-icons/tb';
import { Logo } from '../common/Logo';
import { LanguageSwitcher } from '../common/LanguageSwitcher';
import { DevThemeSelector } from '../common/DevThemeSelector';
import { useCart } from '../../context/CartContext';
import { useCompare } from '../../context/CompareContext';
import { useAuth } from '../../context/AuthContext';

export const Header: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { cartCount, openDrawer } = useCart();
  const { compareCount } = useCompare();
  const { user, isAuthenticated, logout } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/products?search=${encodeURIComponent(searchQuery.trim())}`);
    } else {
      navigate('/products');
    }
  };

  const userMenuItems: MenuProps['items'] = [
    {
      key: 'profile',
      label: (
        <Link to="/account" style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <FiUser /> {t('account.tabProfile', 'Thông tin tài khoản')}
        </Link>
      ),
    },
    {
      key: 'orders',
      label: (
        <Link to="/account" style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <FiPackage /> {t('account.tabOrders', 'Đơn hàng của tôi')}
        </Link>
      ),
    },
    {
      key: 'change-password',
      label: (
        <Link to="/change-password" style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <FiLock /> {t('auth.changePasswordTitle', 'Đổi mật khẩu')}
        </Link>
      ),
    },
    {
      type: 'divider',
    },
    {
      key: 'logout',
      danger: true,
      label: (
        <span
          onClick={() => {
            logout();
            navigate('/login');
          }}
          style={{ display: 'flex', alignItems: 'center', gap: 8 }}
        >
          <LogoutOutlined /> {t('account.logout', 'Đăng xuất')}
        </span>
      ),
    },
  ];

  const navLinks = (
    <>
      <NavLink to="/products" end>
        {t('nav.products', 'Sản phẩm')}
      </NavLink>
      <NavLink to="/components">
        {t('nav.components', 'Linh kiện')}
      </NavLink>
      <NavLink to="/builder">
        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
          <FiCpu style={{ fontSize: 13 }} />
          {t('nav.builder', 'PC Builder')}
        </span>
      </NavLink>
      <NavLink to="/compare">
        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
          <TbArrowsDiff style={{ fontSize: 13 }} />
          {t('nav.compare', 'So sánh')}
          {compareCount > 0 && <span style={{ color: '#67e8f9' }}>({compareCount})</span>}
        </span>
      </NavLink>
      <Link to="/products?sort=discount">
        {t('nav.deals', 'Khuyến mãi')}
      </Link>
    </>
  );

  return (
    <>
      <div className="topline">
        <div className="container" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div className="topline-info" style={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: 12 }}>
            <span>{t('topline.genuine', 'Hệ thống linh kiện PC chính hãng')}</span>
            <span style={{ color: '#444' }}>|</span>
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5 }}>
              <FiTruck style={{ color: '#67e8f9' }} />
              <span>{t('topline.delivery', 'Giao hàng toàn quốc')}</span>
            </span>
            <span style={{ color: '#444' }}>·</span>
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5 }}>
              <FiHeadphones style={{ color: '#67e8f9' }} />
              <span>{t('topline.support', 'Hỗ trợ kỹ thuật 24/7')}</span>
            </span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
            <Link to="/track-order" style={{ color: '#a6a9b2', fontSize: 12 }}>
              {t('nav.trackOrder', 'Tra cứu đơn hàng')}
            </Link>
            <LanguageSwitcher />
            <DevThemeSelector />
          </div>
        </div>
      </div>

      <header className="header">
        <div className="container head">
          <button
            className="mobile icon"
            onClick={() => setMobileMenuOpen(true)}
            aria-label="Open mobile menu"
            type="button"
          >
            <MenuOutlined />
          </button>

          <Logo />

          <form className="search" onSubmit={handleSearchSubmit}>
            <SearchOutlined style={{ color: '#888' }} />
            <input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t('common.searchPlaceholder', 'Tìm linh kiện, thương hiệu, mã sản phẩm...')}
              aria-label="Search input"
            />
            <button type="submit" aria-label="Submit search">
              <SearchOutlined />
            </button>
          </form>

          <div className="head-actions">
            {isAuthenticated && user ? (
              <Dropdown menu={{ items: userMenuItems }} placement="bottomRight" arrow>
                <Link to="/account" aria-label="Account" style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <div
                    style={{
                      width: 32,
                      height: 32,
                      borderRadius: '50%',
                      background: '#242730',
                      border: '1px solid #67e8f9',
                      display: 'grid',
                      placeItems: 'center',
                      color: '#67e8f9',
                      fontSize: 14,
                    }}
                  >
                    <FiUser />
                  </div>
                  <span>
                    <b style={{ color: '#f4f4f5', fontSize: 13 }}>{user.fullName.split(' ').slice(-1)[0]}</b>
                    <small style={{ color: '#67e8f9', display: 'flex', alignItems: 'center', gap: 2, fontSize: 11 }}>
                      {t('nav.account', 'Tài khoản')} <DownOutlined style={{ fontSize: 10 }} />
                    </small>
                  </span>
                </Link>
              </Dropdown>
            ) : (
              <Link to="/login" aria-label="Login">
                <FiUser style={{ fontSize: 18 }} />
                <span>
                  {t('nav.account', 'Tài khoản')}
                  <small style={{ fontSize: 11 }}>{t('nav.login', 'Đăng nhập')}</small>
                </span>
              </Link>
            )}

            <Tooltip title={t('nav.cart', 'Giỏ hàng')} placement="bottom">
              <button onClick={openDrawer} aria-label="Shopping Cart" type="button" style={{ background: 'none', border: 0, padding: 0 }}>
                <Badge count={cartCount} offset={[4, -4]} overflowCount={99}>
                  <FiShoppingCart style={{ fontSize: 19, color: '#f4f4f5' }} />
                </Badge>
              </button>
            </Tooltip>
          </div>
        </div>

        <nav className="container nav">
          <Link className="navcat" to="/products">
            <AppstoreOutlined />
            <span>{t('nav.categories', 'DANH MỤC SẢN PHẨM')}</span>
            <DownOutlined style={{ fontSize: 10, marginLeft: 2 }} />
          </Link>
          <div style={{ display: 'flex', gap: 24, alignItems: 'center' }}>
            {navLinks}
          </div>
          <Link className="hot" to="/products?sort=discount">
            <FireFilled /> {t('nav.flashSale', 'FLASH SALE')} <b>{t('nav.hot', 'HOT')}</b>
          </Link>
        </nav>
      </header>

      <Drawer
        title={<Logo />}
        open={mobileMenuOpen}
        onClose={() => setMobileMenuOpen(false)}
        placement="left"
      >
        <div className="mobile-links" onClick={() => setMobileMenuOpen(false)}>
          {navLinks}
          <div style={{ margin: '12px 0', borderTop: '1px solid #2a2d34', paddingTop: 12 }}>
            <Link to="/account" style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <FiUser /> {t('nav.account', 'Tài khoản')}
            </Link>
            <Link to="/change-password" style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <FiLock /> {t('auth.changePasswordTitle', 'Đổi mật khẩu')}
            </Link>
            <Link to="/forgot-password" style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <KeyOutlined /> {t('auth.forgotTitle', 'Khôi phục mật khẩu')}
            </Link>
            <Link to="/track-order" style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <FiTruck /> {t('nav.trackOrder', 'Tra cứu đơn hàng')}
            </Link>
          </div>
          <div style={{ paddingTop: 16, borderTop: '1px solid #333' }}>
            <LanguageSwitcher />
          </div>
        </div>
      </Drawer>
    </>
  );
};
