import React from 'react';
import { Drawer, Button } from 'antd';
import { Link, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { FiTrash2, FiPlus, FiMinus, FiShoppingBag } from 'react-icons/fi';
import { useCart } from '../../context/CartContext';
import { formatCurrency } from '../../utils/format';

export const CartDrawer: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const {
    cart,
    isDrawerOpen,
    closeDrawer,
    updateQuantity,
    removeFromCart,
    summary,
  } = useCart();

  const handleCheckout = () => {
    closeDrawer();
    navigate('/checkout');
  };

  return (
    <Drawer
      title={
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <FiShoppingBag style={{ color: '#67e8f9', fontSize: 18 }} />
          <span>{t('cart.title', 'Giỏ hàng')}</span>
          <span style={{ fontSize: 11, color: '#888' }}>({summary.totalItems})</span>
        </div>
      }
      open={isDrawerOpen}
      onClose={closeDrawer}
      styles={{ wrapper: { width: 460, maxWidth: '100vw' } }}
      footer={
        cart.length > 0 ? (
          <div className="drawer-foot">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontSize: 12, color: '#aaa' }}>{t('cart.total', 'Tổng cộng')}:</span>
              <b>{formatCurrency(summary.total)}</b>
            </div>
            <Button type="primary" block size="large" onClick={handleCheckout}>
              {t('common.proceedToCheckout', 'Tiến hành thanh toán')}
            </Button>
            <Link
              to="/cart"
              onClick={closeDrawer}
              style={{ textAlign: 'center', color: '#67e8f9', fontSize: 12 }}
            >
              {t('common.viewCart', 'Xem giỏ hàng chi tiết')}
            </Link>
          </div>
        ) : null
      }
    >
      {cart.length > 0 ? (
        <div className="cartitems">
          {cart.map((item) => (
            <div className="cartitem" key={item.id}>
              <img src={item.image} alt={item.name} />
              <span>
                <Link to={`/product/${item.id}`} onClick={closeDrawer}>
                  {item.name}
                </Link>
                <b>{formatCurrency(item.price)}</b>
                <div className="qty">
                  <button
                    onClick={() => updateQuantity(item.id, item.qty - 1)}
                    aria-label={`Decrease quantity of ${item.name}`}
                    type="button"
                  >
                    <FiMinus />
                  </button>
                  <span>{item.qty}</span>
                  <button
                    onClick={() => updateQuantity(item.id, item.qty + 1)}
                    aria-label={`Increase quantity of ${item.name}`}
                    type="button"
                  >
                    <FiPlus />
                  </button>
                </div>
              </span>
              <button
                onClick={() => removeFromCart(item.id)}
                aria-label={`Remove ${item.name} from cart`}
                style={{ color: '#888', border: 'none', background: 'none', cursor: 'pointer' }}
                type="button"
              >
                <FiTrash2 style={{ fontSize: 16 }} />
              </button>
            </div>
          ))}
        </div>
      ) : (
        <div className="emptycart">
          <FiShoppingBag style={{ fontSize: 44, color: '#555', margin: '0 auto 12px' }} />
          <h3>{t('cart.emptyTitle', 'Giỏ hàng đang trống')}</h3>
          <p>{t('cart.emptyDesc', 'Khám phá linh kiện và thêm sản phẩm bạn yêu thích.')}</p>
          <Button
            type="primary"
            onClick={() => {
              closeDrawer();
              navigate('/products');
            }}
            style={{ marginTop: 14 }}
          >
            {t('common.continueShopping', 'Tiếp tục mua sắm')}
          </Button>
        </div>
      )}
    </Drawer>
  );
};
