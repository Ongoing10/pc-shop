import React from 'react';
import { Dropdown, Button } from 'antd';
import type { MenuProps } from 'antd';
import { useTranslation } from 'react-i18next';
import { IoLanguageOutline } from 'react-icons/io5';
import { FiCheck } from 'react-icons/fi';
import { useAppTheme } from '../../context/ThemeContext';

export const LanguageSwitcher: React.FC = () => {
  const { i18n } = useTranslation();
  const { setLanguage } = useAppTheme();
  const currentLang = i18n.language || 'vi';

  const items: MenuProps['items'] = [
    {
      key: 'vi',
      label: (
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12, minWidth: 100 }}>
          <span>🇻🇳 Tiếng Việt</span>
          {currentLang === 'vi' && <FiCheck style={{ color: '#67e8f9' }} />}
        </div>
      ),
      onClick: () => setLanguage('vi'),
    },
    {
      key: 'en',
      label: (
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12, minWidth: 100 }}>
          <span>🇺🇸 English</span>
          {currentLang === 'en' && <FiCheck style={{ color: '#67e8f9' }} />}
        </div>
      ),
      onClick: () => setLanguage('en'),
    },
  ];

  return (
    <Dropdown menu={{ items }} placement="bottomRight" trigger={['click']}>
      <Button
        type="text"
        size="small"
        style={{
          display: 'inline-flex',
          alignItems: 'center',
          gap: 6,
          color: '#c4c6cc',
          border: '1px solid rgba(255,255,255,0.12)',
          background: 'rgba(255,255,255,0.04)',
          borderRadius: 6,
          padding: '4px 8px',
          fontSize: 11,
          height: 28,
        }}
        aria-label="Change language"
      >
        <IoLanguageOutline style={{ fontSize: 14, color: '#67e8f9' }} />
        <span>{currentLang === 'vi' ? 'VI' : 'EN'}</span>
      </Button>
    </Dropdown>
  );
};
