import React, { useState, useEffect } from 'react';
import { ArrowUpOutlined } from '@ant-design/icons';

export const ScrollToTop: React.FC = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 300) {
        setVisible(true);
      } else {
        setVisible(false);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth',
    });
  };

  if (!visible) return null;

  return (
    <button
      onClick={scrollToTop}
      aria-label="Scroll to top"
      type="button"
      style={{
        position: 'fixed',
        bottom: 24,
        right: 24,
        zIndex: 999,
        width: 44,
        height: 44,
        borderRadius: '50%',
        background: 'rgba(18, 22, 41, 0.85)',
        backdropFilter: 'blur(12px)',
        WebkitBackdropFilter: 'blur(12px)',
        border: '1px solid rgba(103, 232, 249, 0.4)',
        color: '#67e8f9',
        display: 'grid',
        placeItems: 'center',
        cursor: 'pointer',
        boxShadow: '0 8px 30px rgba(103, 232, 249, 0.25)',
        transition: 'all 0.25s ease',
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.transform = 'translateY(-3px) scale(1.05)';
        e.currentTarget.style.borderColor = '#67e8f9';
        e.currentTarget.style.boxShadow = '0 12px 35px rgba(103, 232, 249, 0.4)';
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.transform = 'translateY(0) scale(1)';
        e.currentTarget.style.borderColor = 'rgba(103, 232, 249, 0.4)';
        e.currentTarget.style.boxShadow = '0 8px 30px rgba(103, 232, 249, 0.25)';
      }}
    >
      <ArrowUpOutlined style={{ fontSize: 18 }} />
    </button>
  );
};
