import React from 'react';
import { Link } from 'react-router-dom';
import { ThunderboltFilled } from '@ant-design/icons';
import { useTranslation } from 'react-i18next';

interface LogoProps {
  size?: 'normal' | 'small' | 'large';
  className?: string;
}

export const Logo: React.FC<LogoProps> = ({ className = '' }) => {
  const { t } = useTranslation();

  return (
    <Link to="/" className={`logo ${className}`} aria-label="NEXUS PC Home">
      <i>
        <ThunderboltFilled />
      </i>
      <span>
        <b>
          NEXUS<span>PC</span>
        </b>
        <small>{t('common.appTagline', 'BUILD YOUR NEXT LEVEL')}</small>
      </span>
    </Link>
  );
};
