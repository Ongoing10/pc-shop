import React from 'react';
import { Select } from 'antd';
import { BgColorsOutlined } from '@ant-design/icons';
import { useAppTheme } from '../../context/ThemeContext';

export const DevThemeSelector: React.FC = () => {
  const { currentTheme, setTheme, availableThemes } = useAppTheme();

  return (
    <div style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
      <span style={{ fontSize: 11, color: '#f5ad48', fontWeight: 600, display: 'inline-flex', alignItems: 'center', gap: 4 }}>
        <BgColorsOutlined /> Dev Theme:
      </span>
      <Select
        size="small"
        value={currentTheme}
        onChange={(val) => setTheme(val)}
        style={{ width: 175 }}
        options={availableThemes.map((th) => ({
          value: th.id,
          label: (
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 11 }}>
              <span
                style={{
                  width: 10,
                  height: 10,
                  borderRadius: '50%',
                  background: th.primaryColor,
                  display: 'inline-block',
                }}
              />
              <span>{th.name}</span>
            </div>
          ),
        }))}
      />
    </div>
  );
};
