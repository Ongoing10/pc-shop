import React, { ReactNode } from 'react';

interface SectionTitleProps {
  eyebrow?: string;
  title: string;
  desc?: string;
  action?: ReactNode;
}

export const SectionTitle: React.FC<SectionTitleProps> = ({ eyebrow, title, desc, action }) => {
  return (
    <div className="section-title">
      <div>
        {eyebrow && <small>{eyebrow}</small>}
        <h2>{title}</h2>
        {desc && <p>{desc}</p>}
      </div>
      {action}
    </div>
  );
};
