import React from 'react';
import { Link } from 'react-router-dom';
import { Checkbox } from 'antd';
import { useTranslation } from 'react-i18next';
import { StarFilled } from '@ant-design/icons';
import { FiHeart, FiShoppingCart } from 'react-icons/fi';
import { FaHeart } from 'react-icons/fa';
import { Product } from '../../types/product';
import { useCart } from '../../context/CartContext';
import { useFavorites } from '../../context/FavoritesContext';
import { useCompare } from '../../context/CompareContext';
import { formatCurrency, getCategoryName } from '../../utils/format';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { t } = useTranslation();
  const { addToCart } = useCart();
  const { isFavorite, toggleFavorite } = useFavorites();
  const { isComparing, toggleCompare } = useCompare();

  const isLiked = isFavorite(product.id);
  const isCompared = isComparing(product.id);

  const getRibbonClass = (tag?: string) => {
    if (!tag) return '';
    return tag.toLowerCase().replace(/\s+/g, '-');
  };

  return (
    <article className="product" data-testid={`product-card-${product.id}`}>
      <div className="pimg">
        {product.tag && (
          <b className={`ribbon ${getRibbonClass(product.tag)}`}>
            {product.tag}
          </b>
        )}
        <Link to={`/product/${product.id}`} aria-label={product.name}>
          <img src={product.image} alt={product.name} loading="lazy" />
        </Link>
        <button
          className={`fav ${isLiked ? 'liked' : ''}`}
          onClick={(e) => {
            e.preventDefault();
            toggleFavorite(product.id);
          }}
          aria-label={isLiked ? 'Remove from wishlist' : 'Add to wishlist'}
          type="button"
        >
          {isLiked ? <FaHeart style={{ color: '#ff6b78' }} /> : <FiHeart />}
        </button>
        <Checkbox
          checked={isCompared}
          onChange={() => toggleCompare(product.id)}
          aria-label={`So sánh ${product.name}`}
        >
          {t('common.compare', 'So sánh')}
        </Checkbox>
      </div>

      <div className="pbody">
        <small>{getCategoryName(product.category)}</small>
        <Link className="pname" to={`/product/${product.id}`}>
          {product.name}
        </Link>
        <div className="specs">
          {product.specs.map((spec, i) => (
            <span key={i}>{spec}</span>
          ))}
        </div>
        <div className="rating">
          <StarFilled /> <b>{product.rating}</b>{' '}
          <span>({t('common.reviews', { count: product.reviews, defaultValue: `${product.reviews} đánh giá` })})</span>
        </div>
        <strong>{formatCurrency(product.price)}</strong>
        {product.oldPrice && product.oldPrice > product.price && (
          <del>{formatCurrency(product.oldPrice)}</del>
        )}
        <div className="pfoot">
          <span className="stock">
            ● {t('common.stockRemaining', { count: product.stock, defaultValue: `Còn ${product.stock} sản phẩm` })}
          </span>
          <button
            onClick={() => addToCart(product, 1)}
            aria-label={`Thêm ${product.name} vào giỏ hàng`}
            title={t('common.addToCart', 'Thêm vào giỏ')}
            type="button"
          >
            <FiShoppingCart style={{ fontSize: 14 }} />
          </button>
        </div>
      </div>
    </article>
  );
};
