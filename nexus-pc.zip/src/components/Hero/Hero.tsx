import React, { useState, useRef, useEffect } from 'react';
import { IMAGES, COPY } from './heroConfig';
import { useHeroAnimation } from './useHeroAnimation';
import './hero.css';

export interface HeroProps {
  className?: string;
}

export default function Hero({ className = '' }: HeroProps) {
  const heroRef = useRef<HTMLElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [mode, setMode] = useState<0 | 1>(1); // Initial state: Gaming
  const [shownSet, setShownSet] = useState<0 | 1>(1);

  const { select } = useHeroAnimation(heroRef, canvasRef, setShownSet);

  // Automatically switch mode every 20 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setMode((prev) => {
        const next = prev === 0 ? 1 : 0;
        select(next);
        return next;
      });
    }, 12000);

    return () => clearInterval(interval);
  }, [select]);

  return (
    <section className={`hero ${className}`} ref={heroRef} aria-label="NovaBuild hero">
      {/* Layer 1: Sky backdrop */}
      <div className="sky" aria-hidden="true">
        <img src={IMAGES.bgOffice} alt="" decoding="async" onError={(e) => { (e.target as HTMLElement).style.display = 'none'; }} />
        <img className="bg-gaming" src={IMAGES.bgGaming} alt="" decoding="async" onError={(e) => { (e.target as HTMLElement).style.display = 'none'; }} />
      </div>

      {/* Layer 2: Moving desk & PC sets */}
      <div className="home" aria-hidden="true">
        {/* Office Set (0) */}
        <div className={`set ${shownSet === 0 ? 'is-on' : ''}`}>
          <img className="ground" src={IMAGES.deskOffice} alt="" decoding="async" onError={(e) => { (e.target as HTMLElement).style.display = 'none'; }} />
          <img className="pc-cutout" src={IMAGES.pcOffice} alt="Cấu hình PC Văn phòng tối ưu, sang trọng và bền bỉ" decoding="async" onError={(e) => { (e.target as HTMLElement).style.display = 'none'; }} />
        </div>

        {/* Gaming Set (1) */}
        <div className={`set ${shownSet === 1 ? 'is-on' : ''}`}>
          <img className="ground" src={IMAGES.deskGaming} alt="" decoding="async" onError={(e) => { (e.target as HTMLElement).style.display = 'none'; }} />
          <img className="pc-cutout" src={IMAGES.pcGaming} alt="Cấu hình PC Gaming hiệu năng cao, tản nhiệt nước và đèn RGB rực rỡ" decoding="async" onError={(e) => { (e.target as HTMLElement).style.display = 'none'; }} />
        </div>
      </div>

      {/* Layer 3: Tilt / glass depth blur */}
      <div className="tilt" aria-hidden="true" />

      {/* Layer 4: Mist canvas */}
      <canvas className="fog" ref={canvasRef} aria-hidden="true" />

      {/* Layer 5: UI Content */}
      <div className="ui">
        <h1>
          <span className="line-1">{COPY.headline1}</span>
          <i>{COPY.headline2Pre}</i> <span>{COPY.headline2Highlight}</span>
        </h1>

        <div className="dock">
          <p className="caption">
            CPU, VGA, RAM, mainboard chính hãng — tư vấn cấu hình miễn phí,
            <br />
            bảo hành 36 tháng và giao nhanh toàn quốc.
          </p>
        </div>
      </div>
    </section>
  );
}
