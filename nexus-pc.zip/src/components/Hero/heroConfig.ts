export const IMAGES = {
  bgOffice:   "https://images.unsplash.com/photo-1524758631624-e2822e304c36?q=80&w=1600&auto=format&fit=crop", // bright blurred home-office, no PC (w=1600)
  bgGaming:   "https://images.unsplash.com/photo-1550745165-9bc0b252726f?q=80&w=1600&auto=format&fit=crop", // dark gaming room, neon, no PC (w=1600)
  deskOffice: "https://images.unsplash.com/photo-1587831994791-bc36ed55b58c?q=80&w=2560&auto=format&fit=crop", // full photo, white desk + PC (w=2560)
  pcOffice:   "https://images.unsplash.com/photo-1587202372775-e229f172b9d7?q=80&w=2560&auto=format&fit=crop", // transparent cutout, white/silver tower, no RGB
  deskGaming: "https://images.unsplash.com/photo-1616469829941-c7200edec809?q=80&w=2560&auto=format&fit=crop", // full photo, dark desk + PC (w=2560)
  pcGaming:   "https://images.unsplash.com/photo-1587202372634-32705e3bf49c?q=80&w=2560&auto=format&fit=crop", // transparent cutout, black tower, RGB fans, glowing GPU
} as const;

export const ANIM = { SINK: 240, RISE: 820, DEPTH: 0.27 } as const;

export const COPY = {
  headline1: "Build PC trong mơ",
  headline2Pre: "với giá",
  headline2Highlight: "linh kiện tốt nhất",
  officeLabel: "Văn phòng",
  officeSub: "Từ 8 triệu",
  gamingLabel: "Gaming",
  gamingSub: "Từ 25 triệu",
  caption: "CPU, VGA, RAM, mainboard chính hãng — tư vấn cấu hình miễn phí,\nbảo hành 36 tháng và giao nhanh toàn quốc.",
} as const;
