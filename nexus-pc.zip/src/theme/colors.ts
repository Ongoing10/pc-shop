/**
 * Global Color Tokens for NovaBuild
 */
export const colors = {
  primary: '#67e8f9',
  primaryHover: '#a5d8ff',
  primaryActive: '#38bdf8',
  primaryLight: 'rgba(103, 232, 249, 0.12)',

  accentOrange: '#67e8f9',
  accentGreen: '#34d399',
  accentGreenBg: 'rgba(52, 211, 153, 0.15)',
  accentBlue: '#3b82f6',
  accentPurple: '#c4b5fd',
  accentGold: '#fbbf24',
  accentRed: '#f43f5e',

  background: '#0a0d1a',
  backgroundElevated: '#121629',
  backgroundSubtle: '#0d1224',
  backgroundInput: 'rgba(255, 255, 255, 0.05)',
  backgroundHeader: 'rgba(10, 13, 26, 0.85)',
  backgroundTopline: 'rgba(8, 11, 22, 0.95)',

  border: 'rgba(255, 255, 255, 0.12)',
  borderLight: 'rgba(255, 255, 255, 0.18)',
  borderHighlight: 'rgba(103, 232, 249, 0.35)',

  textPrimary: '#f4f4f5',
  textSecondary: '#94a3b8',
  textMuted: '#64748b',
  textInverse: '#0a0d1a',

  statusInStock: '#34d399',
  statusLowStock: '#fbbf24',
  statusOutOfStock: '#f43f5e',
} as const;

export type ThemeColors = typeof colors;
