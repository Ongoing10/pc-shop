import type { ThemeConfig } from 'antd';
import { theme } from 'antd';
import { colors } from './colors';

/**
 * Ant Design Theme Configuration
 * Injected into Ant Design's ConfigProvider.
 */
export const antdDarkTheme: ThemeConfig = {
  algorithm: theme.darkAlgorithm,
  token: {
    colorPrimary: colors.primary,
    colorInfo: colors.primary,
    colorSuccess: colors.accentGreen,
    colorWarning: colors.accentGold,
    colorError: colors.accentRed,
    colorBgBase: colors.background,
    colorBgContainer: colors.backgroundElevated,
    colorBgElevated: colors.backgroundElevated,
    colorTextBase: colors.textPrimary,
    colorTextSecondary: colors.textSecondary,
    colorBorder: colors.border,
    colorBorderSecondary: colors.borderLight,
    borderRadius: 8,
    fontFamily: "'Be Vietnam Pro', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
    controlHeight: 40,
    fontSize: 13,
    motionEaseOutBack: 'cubic-bezier(0.16, 1, 0.3, 1)',
    motionEaseInBack: 'cubic-bezier(0.7, 0, 0.84, 0)',
  },
  components: {
    Button: {
      colorPrimary: colors.primary,
      colorPrimaryHover: colors.primaryHover,
      colorPrimaryActive: colors.primaryActive,
      fontWeight: 600,
      borderRadius: 8,
    },
    Input: {
      colorBgContainer: colors.backgroundInput,
      colorBorder: colors.borderLight,
      colorText: colors.textPrimary,
      colorTextPlaceholder: colors.textMuted,
    },
    Select: {
      colorBgContainer: colors.backgroundInput,
      colorBorder: colors.borderLight,
      colorText: colors.textPrimary,
      colorBgElevated: colors.backgroundElevated,
      optionSelectedBg: colors.primaryLight,
    },
    Drawer: {
      colorBgElevated: colors.backgroundElevated,
      colorText: colors.textPrimary,
    },
    Card: {
      colorBgContainer: colors.backgroundElevated,
      colorBorderSecondary: colors.border,
    },
    Slider: {
      colorPrimary: colors.primary,
      trackBg: colors.primary,
      handleColor: colors.primary,
      handleActiveColor: colors.primaryHover,
    },
    Tag: {
      borderRadiusSM: 4,
    },
    Checkbox: {
      colorPrimary: colors.primary,
    },
    Radio: {
      colorPrimary: colors.primary,
    },
    Steps: {
      colorPrimary: colors.primary,
    },
    Divider: {
      colorSplit: colors.border,
    },
    Tabs: {
      colorPrimary: colors.primary,
      itemSelectedColor: colors.primary,
    },
    Skeleton: {
      colorFill: '#242730',
      colorFillContent: '#1c1e24',
      borderRadiusSM: 6,
    },
  },
};
