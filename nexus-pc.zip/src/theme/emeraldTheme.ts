import type { ThemeConfig } from 'antd';
import { theme } from 'antd';

export const emeraldColors = {
  primary: '#10b981',
  primaryHover: '#34d399',
  primaryActive: '#059669',
  primaryLight: 'rgba(16, 185, 129, 0.12)',

  accentOrange: '#f59e0b',
  accentGreen: '#10b981',
  accentGreenBg: 'rgba(16, 185, 129, 0.15)',
  accentBlue: '#3b82f6',
  accentPurple: '#a855f7',
  accentGold: '#fbbf24',
  accentRed: '#ef4444',

  background: '#09120e',
  backgroundElevated: '#111b15',
  backgroundSubtle: '#0d1712',
  backgroundInput: '#18241e',
  backgroundHeader: 'rgba(9, 18, 14, 0.92)',
  backgroundTopline: '#050a08',

  border: '#1f3328',
  borderLight: '#2d4d3c',
  borderHighlight: 'rgba(16, 185, 129, 0.35)',

  textPrimary: '#f0fdf4',
  textSecondary: '#9ca3af',
  textMuted: '#6b7280',
  textInverse: '#09120e',

  statusInStock: '#10b981',
  statusLowStock: '#fbbf24',
  statusOutOfStock: '#ef4444',
} as const;

export const emeraldAntdTheme: ThemeConfig = {
  algorithm: theme.darkAlgorithm,
  token: {
    colorPrimary: emeraldColors.primary,
    colorInfo: emeraldColors.primary,
    colorSuccess: emeraldColors.accentGreen,
    colorWarning: emeraldColors.accentGold,
    colorError: emeraldColors.accentRed,
    colorBgBase: emeraldColors.background,
    colorBgContainer: emeraldColors.backgroundElevated,
    colorBgElevated: emeraldColors.backgroundElevated,
    colorTextBase: emeraldColors.textPrimary,
    colorTextSecondary: emeraldColors.textSecondary,
    colorBorder: emeraldColors.border,
    colorBorderSecondary: emeraldColors.borderLight,
    borderRadius: 8,
    fontFamily: "'Be Vietnam Pro', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
    controlHeight: 40,
    fontSize: 13,
  },
  components: {
    Button: {
      colorPrimary: emeraldColors.primary,
      colorPrimaryHover: emeraldColors.primaryHover,
      colorPrimaryActive: emeraldColors.primaryActive,
      fontWeight: 600,
      borderRadius: 8,
    },
    Input: {
      colorBgContainer: emeraldColors.backgroundInput,
      colorBorder: emeraldColors.borderLight,
      colorText: emeraldColors.textPrimary,
      colorTextPlaceholder: emeraldColors.textMuted,
    },
    Select: {
      colorBgContainer: emeraldColors.backgroundInput,
      colorBorder: emeraldColors.borderLight,
      colorText: emeraldColors.textPrimary,
      colorBgElevated: emeraldColors.backgroundElevated,
      optionSelectedBg: emeraldColors.primaryLight,
    },
    Card: {
      colorBgContainer: emeraldColors.backgroundElevated,
      colorBorderSecondary: emeraldColors.border,
    },
    Slider: {
      colorPrimary: emeraldColors.primary,
      trackBg: emeraldColors.primary,
      handleColor: emeraldColors.primary,
      handleActiveColor: emeraldColors.primaryHover,
    },
    Tabs: {
      colorPrimary: emeraldColors.primary,
      itemSelectedColor: emeraldColors.primary,
    },
  },
};
