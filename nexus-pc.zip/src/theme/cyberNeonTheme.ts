import type { ThemeConfig } from 'antd';
import { theme } from 'antd';

export const cyberNeonColors = {
  primary: '#06b6d4',
  primaryHover: '#22d3ee',
  primaryActive: '#0891b2',
  primaryLight: 'rgba(6, 182, 212, 0.12)',

  accentOrange: '#f97316',
  accentGreen: '#10b981',
  accentGreenBg: 'rgba(16, 185, 129, 0.15)',
  accentBlue: '#06b6d4',
  accentPurple: '#8b5cf6',
  accentGold: '#facc15',
  accentRed: '#f43f5e',

  background: '#080d16',
  backgroundElevated: '#111827',
  backgroundSubtle: '#0d1320',
  backgroundInput: '#1f2937',
  backgroundHeader: 'rgba(8, 13, 22, 0.92)',
  backgroundTopline: '#04070c',

  border: '#1e293b',
  borderLight: '#334155',
  borderHighlight: 'rgba(6, 182, 212, 0.35)',

  textPrimary: '#f8fafc',
  textSecondary: '#94a3b8',
  textMuted: '#64748b',
  textInverse: '#080d16',

  statusInStock: '#10b981',
  statusLowStock: '#facc15',
  statusOutOfStock: '#f43f5e',
} as const;

export const cyberNeonAntdTheme: ThemeConfig = {
  algorithm: theme.darkAlgorithm,
  token: {
    colorPrimary: cyberNeonColors.primary,
    colorInfo: cyberNeonColors.primary,
    colorSuccess: cyberNeonColors.accentGreen,
    colorWarning: cyberNeonColors.accentGold,
    colorError: cyberNeonColors.accentRed,
    colorBgBase: cyberNeonColors.background,
    colorBgContainer: cyberNeonColors.backgroundElevated,
    colorBgElevated: cyberNeonColors.backgroundElevated,
    colorTextBase: cyberNeonColors.textPrimary,
    colorTextSecondary: cyberNeonColors.textSecondary,
    colorBorder: cyberNeonColors.border,
    colorBorderSecondary: cyberNeonColors.borderLight,
    borderRadius: 8,
    fontFamily: "'Be Vietnam Pro', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
    controlHeight: 40,
    fontSize: 13,
  },
  components: {
    Button: {
      colorPrimary: cyberNeonColors.primary,
      colorPrimaryHover: cyberNeonColors.primaryHover,
      colorPrimaryActive: cyberNeonColors.primaryActive,
      fontWeight: 600,
      borderRadius: 8,
    },
    Input: {
      colorBgContainer: cyberNeonColors.backgroundInput,
      colorBorder: cyberNeonColors.borderLight,
      colorText: cyberNeonColors.textPrimary,
      colorTextPlaceholder: cyberNeonColors.textMuted,
    },
    Select: {
      colorBgContainer: cyberNeonColors.backgroundInput,
      colorBorder: cyberNeonColors.borderLight,
      colorText: cyberNeonColors.textPrimary,
      colorBgElevated: cyberNeonColors.backgroundElevated,
      optionSelectedBg: cyberNeonColors.primaryLight,
    },
    Card: {
      colorBgContainer: cyberNeonColors.backgroundElevated,
      colorBorderSecondary: cyberNeonColors.border,
    },
    Slider: {
      colorPrimary: cyberNeonColors.primary,
      trackBg: cyberNeonColors.primary,
      handleColor: cyberNeonColors.primary,
      handleActiveColor: cyberNeonColors.primaryHover,
    },
    Tabs: {
      colorPrimary: cyberNeonColors.primary,
      itemSelectedColor: cyberNeonColors.primary,
    },
  },
};
