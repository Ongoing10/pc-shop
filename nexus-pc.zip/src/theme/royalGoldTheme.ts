import type { ThemeConfig } from 'antd';
import { theme } from 'antd';

export const royalGoldColors = {
  primary: '#8b5cf6',
  primaryHover: '#a78bfa',
  primaryActive: '#7c3aed',
  primaryLight: 'rgba(139, 92, 246, 0.12)',

  accentOrange: '#f59e0b',
  accentGreen: '#10b981',
  accentGreenBg: 'rgba(16, 185, 129, 0.15)',
  accentBlue: '#3b82f6',
  accentPurple: '#8b5cf6',
  accentGold: '#f59e0b',
  accentRed: '#ef4444',

  background: '#120d1a',
  backgroundElevated: '#1b1427',
  backgroundSubtle: '#151021',
  backgroundInput: '#261c38',
  backgroundHeader: 'rgba(18, 13, 26, 0.92)',
  backgroundTopline: '#0a0710',

  border: '#2e2142',
  borderLight: '#43315e',
  borderHighlight: 'rgba(139, 92, 246, 0.35)',

  textPrimary: '#faf5ff',
  textSecondary: '#a78bfa',
  textMuted: '#7c6d96',
  textInverse: '#120d1a',

  statusInStock: '#10b981',
  statusLowStock: '#f59e0b',
  statusOutOfStock: '#ef4444',
} as const;

export const royalGoldAntdTheme: ThemeConfig = {
  algorithm: theme.darkAlgorithm,
  token: {
    colorPrimary: royalGoldColors.primary,
    colorInfo: royalGoldColors.primary,
    colorSuccess: royalGoldColors.accentGreen,
    colorWarning: royalGoldColors.accentGold,
    colorError: royalGoldColors.accentRed,
    colorBgBase: royalGoldColors.background,
    colorBgContainer: royalGoldColors.backgroundElevated,
    colorBgElevated: royalGoldColors.backgroundElevated,
    colorTextBase: royalGoldColors.textPrimary,
    colorTextSecondary: royalGoldColors.textSecondary,
    colorBorder: royalGoldColors.border,
    colorBorderSecondary: royalGoldColors.borderLight,
    borderRadius: 8,
    fontFamily: "'Be Vietnam Pro', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
    controlHeight: 40,
    fontSize: 13,
  },
  components: {
    Button: {
      colorPrimary: royalGoldColors.primary,
      colorPrimaryHover: royalGoldColors.primaryHover,
      colorPrimaryActive: royalGoldColors.primaryActive,
      fontWeight: 600,
      borderRadius: 8,
    },
    Input: {
      colorBgContainer: royalGoldColors.backgroundInput,
      colorBorder: royalGoldColors.borderLight,
      colorText: royalGoldColors.textPrimary,
      colorTextPlaceholder: royalGoldColors.textMuted,
    },
    Select: {
      colorBgContainer: royalGoldColors.backgroundInput,
      colorBorder: royalGoldColors.borderLight,
      colorText: royalGoldColors.textPrimary,
      colorBgElevated: royalGoldColors.backgroundElevated,
      optionSelectedBg: royalGoldColors.primaryLight,
    },
    Card: {
      colorBgContainer: royalGoldColors.backgroundElevated,
      colorBorderSecondary: royalGoldColors.border,
    },
    Slider: {
      colorPrimary: royalGoldColors.primary,
      trackBg: royalGoldColors.primary,
      handleColor: royalGoldColors.primary,
      handleActiveColor: royalGoldColors.primaryHover,
    },
    Tabs: {
      colorPrimary: royalGoldColors.primary,
      itemSelectedColor: royalGoldColors.primary,
    },
  },
};
