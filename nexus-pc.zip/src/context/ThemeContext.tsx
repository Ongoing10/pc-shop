import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { useTranslation } from 'react-i18next';
import { colors, ThemeColors } from '../theme/colors';
import { antdDarkTheme } from '../theme/themeConfig';
import { emeraldColors, emeraldAntdTheme } from '../theme/emeraldTheme';
import { cyberNeonColors, cyberNeonAntdTheme } from '../theme/cyberNeonTheme';
import { royalGoldColors, royalGoldAntdTheme } from '../theme/royalGoldTheme';
import type { ThemeConfig } from 'antd';

export interface ThemeOption {
  id: string;
  name: string;
  primaryColor: string;
}

export const availableThemes: ThemeOption[] = [
  { id: 'default', name: 'NEXUS Original (Orange)', primaryColor: '#67e8f9' },
  { id: 'emerald', name: 'Emerald Matrix (Green)', primaryColor: '#10b981' },
  { id: 'cyber', name: 'Cyber Neon (Cyan)', primaryColor: '#06b6d4' },
  { id: 'royal', name: 'Royal Cyber (Purple & Gold)', primaryColor: '#8b5cf6' },
];

interface ThemeContextType {
  colors: Record<string, any>;
  currentTheme: string;
  setTheme: (themeId: string) => void;
  availableThemes: ThemeOption[];
  antdTheme: ThemeConfig;
  currentLanguage: 'vi' | 'en';
  setLanguage: (lang: 'vi' | 'en') => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const ThemeProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const { i18n } = useTranslation();
  const [currentLanguage, setCurrentLanguageState] = useState<'vi' | 'en'>(
    (i18n.language as 'vi' | 'en') || 'vi'
  );

  const [currentTheme, setCurrentThemeState] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('nexus_theme') || 'default';
    }
    return 'default';
  });

  const getThemeData = (themeId: string) => {
    switch (themeId) {
      case 'emerald':
        return { colors: emeraldColors, antdTheme: emeraldAntdTheme };
      case 'cyber':
        return { colors: cyberNeonColors, antdTheme: cyberNeonAntdTheme };
      case 'royal':
        return { colors: royalGoldColors, antdTheme: royalGoldAntdTheme };
      default:
        return { colors: colors, antdTheme: antdDarkTheme };
    }
  };

  const themeData = getThemeData(currentTheme);

  const setTheme = (themeId: string) => {
    setCurrentThemeState(themeId);
    if (typeof window !== 'undefined') {
      localStorage.setItem('nexus_theme', themeId);
    }
  };

  useEffect(() => {
    const tData = getThemeData(currentTheme);
    if (typeof document !== 'undefined') {
      document.documentElement.style.setProperty('--orange', tData.colors.primary);
      document.documentElement.style.setProperty('--bg', tData.colors.background);
      document.documentElement.style.setProperty('--panel', tData.colors.backgroundElevated);
      document.documentElement.style.setProperty('--line', tData.colors.border);
      document.body.style.background = tData.colors.background;
      document.body.style.color = tData.colors.textPrimary;
    }
  }, [currentTheme]);

  const setLanguage = (lang: 'vi' | 'en') => {
    i18n.changeLanguage(lang);
    setCurrentLanguageState(lang);
    if (typeof window !== 'undefined') {
      localStorage.setItem('nexus_lang', lang);
    }
  };

  useEffect(() => {
    if (i18n.language && i18n.language !== currentLanguage) {
      setCurrentLanguageState(i18n.language as 'vi' | 'en');
    }
  }, [i18n.language]);

  return (
    <ThemeContext.Provider
      value={{
        colors: themeData.colors,
        currentTheme,
        setTheme,
        availableThemes,
        antdTheme: themeData.antdTheme,
        currentLanguage,
        setLanguage,
      }}
    >
      {children}
    </ThemeContext.Provider>
  );
};

export const useAppTheme = (): ThemeContextType => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useAppTheme must be used within a ThemeProvider');
  }
  return context;
};
